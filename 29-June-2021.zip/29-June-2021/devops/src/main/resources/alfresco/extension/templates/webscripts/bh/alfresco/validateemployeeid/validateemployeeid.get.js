
function main() {
	var isDatalistItemExist = false;
	var status = "";
	var employeeId = args.employeeId;
	var queryResults = []
	try {
		if(isTrue(employeeId)) {
			var query = "=bhddl:employee_id:'"+employeeId+"'";
			if (query !== "")
			  {
				 queryResults = search.query(
				 {
					query: query,
					language: "fts-alfresco",
					page:
					{
					   maxItems: 10
					},
					sort: null,
					templates: null,
					namespace: null
				 });
				  if (queryResults.length > 0)
				   {
					   isDatalistItemExist = true;
					   status = "Datalistiiem Exist with employee id : "+employeeId
				   }else{
					   status = "No Datalistiiem exist for this employee id : "+employeeId;
				   }
			  }
		}else{
			status = "provide employee id to validate";
		}
	} catch(e) {
		status = e.toString();
	}
	
	model.isDatalistItemExist = isDatalistItemExist;
	model.status = status;

}

function isTrue(i) {
	return i != null && i != undefined && i != '';
}

main();