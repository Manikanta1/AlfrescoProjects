package com.bh.alfresco.devops.webscripts.exception;

import org.springframework.extensions.webscripts.WebScriptException;

@SuppressWarnings("serial")
public class GenericException extends WebScriptException{

	public GenericException(int status, String msgId) {
		super(status, msgId);
	}

}
