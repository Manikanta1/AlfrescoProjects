package com.bh.alfresco.devops.webscripts.migration;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.model.DataListModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.site.SiteInfo;
import org.alfresco.service.cmr.site.SiteService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.bh.alfresco.devops.webscripts.exception.GenericException;
import com.bh.alfresco.devops.webscripts.model.DataListItemModel;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreateDataListItem extends AbstractWebScript{
	
	private ServiceRegistry serviceRegistry;
	private SiteService siteService;
	private SearchService searchService;
	private NodeService nodeService;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
		this.siteService = serviceRegistry.getSiteService();
		this.searchService = serviceRegistry.getSearchService();
		this.nodeService = serviceRegistry.getNodeService();
	}

	public NodeRef getParentNodeRef(DataListItemModel datalistModel) {
		NodeRef parentNodeRef = null;
		String siteName = datalistModel.getSite();
		String dataListName = datalistModel.getDatalistName();
		String dataListTpeName = datalistModel.getDataListType();
		if(StringUtils.isBlank(siteName) || StringUtils.isBlank(dataListTpeName)) {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Site Name and Datalisttype is null");
		}
		SiteInfo siteInfo = siteService.getSite(siteName);
		if(siteInfo == null) {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Provided site doesnot exist : siteName : "+siteName);
		}else {
			NodeRef datalistContainerNodeRef = siteService.getContainer(siteName, "datalists");
			String query = "=PARENT:'"+datalistContainerNodeRef.toString()+"' AND ="+DataListModel.DATALIST_MODEL_PREFIX+":"
			+DataListModel.PROP_DATALIST_ITEM_TYPE.getLocalName()
			+":'"+dataListTpeName+"'";
			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, 
					SearchService.LANGUAGE_FTS_ALFRESCO, query);
			List<NodeRef> dataListNodeRefs = searchResults.getNodeRefs();
			if(dataListNodeRefs.size() > 0) {
				parentNodeRef = dataListNodeRefs.get(0);
			}else {
				throw new GenericException(Status.STATUS_BAD_REQUEST, "No DataList Exist with this type : dataListType : "+dataListTpeName);
			}
		}
		return parentNodeRef;
	}
	
	@SuppressWarnings("unchecked")
	public Map<QName, Serializable> getPropertiesMap(DataListItemModel datalistModel) {
		Map<QName, Serializable> propertiesMap = new HashMap<QName, Serializable>();
		Map<String, Object> inputPropertiesMap = datalistModel.getMetadata();
		if(inputPropertiesMap != null) {
			for(Map.Entry<String, Object> mapEntry : inputPropertiesMap.entrySet()) {
				String key = mapEntry.getKey();
				Object value = mapEntry.getValue();
				if(value instanceof String) {
					String strValue = (String) mapEntry.getValue();
					propertiesMap.put(QName.resolveToQName(serviceRegistry.getNamespaceService(), key), (Serializable) strValue);
				}else if(value instanceof List) {
					List<String> listValue = (List<String>) mapEntry.getValue();
					propertiesMap.put(QName.resolveToQName(serviceRegistry.getNamespaceService(), key), (Serializable) listValue);
				}
			}
		}else {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Metadata is not provided..");
		}
		return propertiesMap;
	}
	
	@SuppressWarnings("unchecked")
	public Map<QName, Serializable> getUpdatePropertiesMap(DataListItemModel datalistModel) {
		Map<QName, Serializable> propertiesMap = new HashMap<QName, Serializable>();
		Map<String, Object> inputPropertiesMap = datalistModel.getUpdateMetadata();
		if(inputPropertiesMap != null) {
			for(Map.Entry<String, Object> mapEntry : inputPropertiesMap.entrySet()) {
				String key = mapEntry.getKey();
				Object value = mapEntry.getValue();
				if(value instanceof String) {
					String strValue = (String) mapEntry.getValue();
					propertiesMap.put(QName.resolveToQName(serviceRegistry.getNamespaceService(), key), (Serializable) strValue);
				}else if(value instanceof List) {
					List<String> listValue = (List<String>) mapEntry.getValue();
					propertiesMap.put(QName.resolveToQName(serviceRegistry.getNamespaceService(), key), (Serializable) listValue);
				}
			}
		}else {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Metadata is not provided..");
		}
		return propertiesMap;
	}
	
	
	public String createDataListItem(WebScriptRequest req, WebScriptResponse res) throws IOException {
		
		String message = null;
		DataListItemModel datalistModel = null;
		String inputJson = req.getContent().getContent();
		
		if(StringUtils.isBlank(inputJson)) {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Provide Valid Input..");
		}
		ObjectMapper objectMapper = new ObjectMapper();
		datalistModel = objectMapper.readValue(inputJson, DataListItemModel.class);
		NodeRef parentNodeRef = getParentNodeRef(datalistModel);
		Map<QName, Serializable> propertiesMap = getPropertiesMap(datalistModel);
		ChildAssociationRef childAssociationRef = nodeService.createNode(parentNodeRef, ContentModel.ASSOC_CONTAINS, 
				QName.resolveToQName(serviceRegistry.getNamespaceService(), datalistModel.getDataListType()), 
				QName.resolveToQName(serviceRegistry.getNamespaceService(), datalistModel.getDataListType()),
				propertiesMap);
		if(childAssociationRef == null) {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Node Creation Failure...");
		}
		message = "DataListItem created successfully";
		return message;
		
	}
	
	public void validateRequest(DataListItemModel datalistModel) {
		String requestType = datalistModel.getRequestType();
		if(StringUtils.isEmpty(requestType) || StringUtils.isBlank(requestType)) {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Provide provide request type as it is mandatory...");
		}else if(!("new".equalsIgnoreCase(requestType) || "update".equalsIgnoreCase(requestType) || "newandupdate".equalsIgnoreCase(requestType))) {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Accepted request typs are : : new, update or newandupdate");
		}else {
			if("update".equalsIgnoreCase(requestType) || "newandupdate".equalsIgnoreCase(requestType)) {
				List<String> validatorList = datalistModel.getValidators();
				if(validatorList == null) {
					throw new GenericException(Status.STATUS_BAD_REQUEST, "Validators list is null");
				}else {
					if(validatorList.size() > 0) {
						Map<String, Object> metadata = datalistModel.getMetadata();
						for(String validator : validatorList) {
							if(metadata != null) {
								if(!metadata.containsKey(validator)) {
									throw new GenericException(Status.STATUS_BAD_REQUEST, "Validator not exist in metadata : validator : "+validator);
								}
							}else {
								throw new GenericException(Status.STATUS_BAD_REQUEST, "Metadata is null");
							}
						}
					}else {
						throw new GenericException(Status.STATUS_BAD_REQUEST, "Validators list is empty");
					}
				}
			}
		}
	}

	
	public NodeRef getExistingNodeRef(DataListItemModel datalistModel) {
		
		NodeRef nodeRef = null;
		List<String> validatorList = datalistModel.getValidators();
		Map<String, Object> metadata = datalistModel.getMetadata();
		int index = 0;
		StringBuilder query = new StringBuilder();
		for(String validator : validatorList) {
			if(metadata.containsKey(validator)) {
				String metadataValue = (String) metadata.get(validator);
				if(index == 0) {
					query.append("=");
					query.append(validator);
					query.append(":");
					query.append("'");
					query.append(metadataValue);
					query.append("'");
				}else {
					query.append(" AND ");
					query.append("=");
					query.append(validator);
					query.append(":");
					query.append("'");
					query.append(metadataValue);
					query.append("'");
				}
				index++;	
			}	
		}
		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, 
				query.toString());
		if(searchResults.length() > 0) {
			if(searchResults.length() == 1) {
				nodeRef = searchResults.getNodeRef(0);
			}else {
				throw new GenericException(Status.STATUS_BAD_REQUEST, "There are more than one node exist with these validators....");
			}
		}else {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "No Nodes exist with these validators...");
		}
		return nodeRef;
	}
	
	public List<NodeRef> getExistingNodeRefs(DataListItemModel datalistModel) {
		
		List<NodeRef> nodeRefList = new ArrayList<NodeRef>();
		List<String> validatorList = datalistModel.getValidators();
		Map<String, Object> metadata = datalistModel.getMetadata();
		int index = 0;
		StringBuilder query = new StringBuilder();
		for(String validator : validatorList) {
			if(metadata.containsKey(validator)) {
				String metadataValue = (String) metadata.get(validator);
				if(index == 0) {
					query.append("=");
					query.append(validator);
					query.append(":");
					query.append("'");
					query.append(metadataValue);
					query.append("'");
				}else {
					query.append(" AND ");
					query.append("=");
					query.append(validator);
					query.append(":");
					query.append("'");
					query.append(metadataValue);
					query.append("'");
				}
				index++;	
			}	
		}
		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, 
				query.toString());
		if(searchResults.length() > 0) {
			nodeRefList = searchResults.getNodeRefs();
		}
		return nodeRefList;
	}
	
	public String createOrUpdateDataListItem(WebScriptRequest req, WebScriptResponse res) throws IOException {
			
		String message = null;
		DataListItemModel datalistModel = null;
		String inputJson = req.getContent().getContent();
		
		if(StringUtils.isBlank(inputJson)) {
			throw new GenericException(Status.STATUS_BAD_REQUEST, "Provide Valid Input..");
		}
		ObjectMapper objectMapper = new ObjectMapper();
		datalistModel = objectMapper.readValue(inputJson, DataListItemModel.class);
		validateRequest(datalistModel);
		String requestType = datalistModel.getRequestType();
		if("newandupdate".equalsIgnoreCase(requestType)) {
			Boolean isItemsUpdated = false;
			List<NodeRef> nodeRefList = getExistingNodeRefs(datalistModel);
			Map<String, Object> updatePropertiesMap = datalistModel.getUpdateMetadata();
			if(updatePropertiesMap != null) {
				if(updatePropertiesMap.size() > 0) {
					Map<QName, Serializable> propertiesMap = getUpdatePropertiesMap(datalistModel);
					for(NodeRef existingNodeRef : nodeRefList) {
						Map<QName, Serializable> updatedPropertiesMap = nodeService.getProperties(existingNodeRef);
						for(Map.Entry<QName, Serializable> mapEntry : propertiesMap.entrySet()) {
							QName qNameKey = mapEntry.getKey();
							if(updatedPropertiesMap != null) {
								if(updatedPropertiesMap.containsKey(qNameKey)) {
									updatedPropertiesMap.replace(qNameKey, mapEntry.getValue());
								}else {
									updatedPropertiesMap.put(qNameKey, mapEntry.getValue());
								}
							}
						}
						nodeService.setProperties(existingNodeRef, updatedPropertiesMap);
						isItemsUpdated = true;
					}
				}
			}
			NodeRef parentNodeRef = getParentNodeRef(datalistModel);
			Map<QName, Serializable> propertiesMap = getPropertiesMap(datalistModel);
			ChildAssociationRef childAssociationRef = nodeService.createNode(parentNodeRef, ContentModel.ASSOC_CONTAINS, 
					QName.resolveToQName(serviceRegistry.getNamespaceService(), datalistModel.getDataListType()), 
					QName.resolveToQName(serviceRegistry.getNamespaceService(), datalistModel.getDataListType()),
					propertiesMap);
			if(childAssociationRef == null) {
				throw new GenericException(Status.STATUS_BAD_REQUEST, "Node Creation Failure...");
			}
			if(isItemsUpdated) {
				message = "DataListItem(s) created and updated successfully";
			}else {
				message = "DataListItem created successfully";
			}

		}else if("update".equalsIgnoreCase(requestType)) {
			NodeRef existingNodeRef = getExistingNodeRef(datalistModel);
			if(existingNodeRef != null) {
				Map<QName, Serializable> propertiesMap = getPropertiesMap(datalistModel);
				nodeService.setProperties(existingNodeRef, propertiesMap);
				message = "DataListItem updated successfully";
			}else {
				throw new GenericException(Status.STATUS_BAD_REQUEST, "Existing NodeREf was null....");
			}
		}else {
			NodeRef parentNodeRef = getParentNodeRef(datalistModel);
			Map<QName, Serializable> propertiesMap = getPropertiesMap(datalistModel);
			ChildAssociationRef childAssociationRef = nodeService.createNode(parentNodeRef, ContentModel.ASSOC_CONTAINS, 
					QName.resolveToQName(serviceRegistry.getNamespaceService(), datalistModel.getDataListType()), 
					QName.resolveToQName(serviceRegistry.getNamespaceService(), datalistModel.getDataListType()),
					propertiesMap);
			if(childAssociationRef == null) {
				throw new GenericException(Status.STATUS_BAD_REQUEST, "Node Creation Failure...");
			}
			message = "DataListItem created successfully";
		}
		return message;
		
	}

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
            public Object doWork() throws Exception {
            	String message = createOrUpdateDataListItem(req, res);
            	JSONObject jsonObject = new JSONObject();
            	jsonObject.put("message", message);
            	res.getWriter().write(jsonObject.toString());
                return null;
            }
        }, AuthenticationUtil.getAdminUserName());

	}

}
