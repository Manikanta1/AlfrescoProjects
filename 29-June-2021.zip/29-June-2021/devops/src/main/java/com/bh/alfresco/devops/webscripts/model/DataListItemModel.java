package com.bh.alfresco.devops.webscripts.model;

import java.util.List;
import java.util.Map;

public class DataListItemModel {
	
	private String site;
	private String datalistName;
	private String dataListType;
	private String requestType;
	private List<String> validators;
	private Map<String, Object> updateMetadata;
	private Map<String, Object> metadata;
	
	public String getDataListType() {
		return dataListType;
	}
	public void setDataListType(String dataListType) {
		this.dataListType = dataListType;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public String getDatalistName() {
		return datalistName;
	}
	public void setDatalistName(String datalistName) {
		this.datalistName = datalistName;
	}
	public Map<String, Object> getMetadata() {
		return metadata;
	}
	public void setMetadata(Map<String, Object> metadata) {
		this.metadata = metadata;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public List<String> getValidators() {
		return validators;
	}
	public void setValidators(List<String> validators) {
		this.validators = validators;
	}
	public Map<String, Object> getUpdateMetadata() {
		return updateMetadata;
	}
	public void setUpdateMetadata(Map<String, Object> updateMetadata) {
		this.updateMetadata = updateMetadata;
	}
	
}
